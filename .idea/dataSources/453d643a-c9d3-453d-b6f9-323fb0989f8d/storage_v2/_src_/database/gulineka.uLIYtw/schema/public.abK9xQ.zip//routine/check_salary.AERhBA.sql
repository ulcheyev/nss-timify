create function check_salary() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW."salary" < 0) THEN RAISE EXCEPTION 'Invalid salary value'; 
	END IF;
	RETURN NEW;
END;
$$;

alter function check_salary() owner to gulineka;

